'use client';
import React, { useEffect, useRef } from 'react';
import Input from '../Input';
import Button from '../Button';
import { faSearch } from '@fortawesome/free-solid-svg-icons';
import * as S from './styles';

type SearchFormProps = {
  term: string;
  setTerm: (term: string) => void;
  onSearch: () => void;      
  onClear: () => void;       
  autoSearch?: boolean;      
  debounceMs?: number;
};

const SearchForm = ({
  term,
  setTerm,
  onSearch,
  onClear,
  autoSearch = false,
  debounceMs = 300,
}: SearchFormProps) => {
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    onSearch();
  };

  const handleClear = () => {
    setTerm('');
    onClear();
  };

  useEffect(() => {
    if (!autoSearch) return;

    if (!term.trim()) {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      onClear();
      return;
    }

    if (timeoutRef.current) clearTimeout(timeoutRef.current);
    timeoutRef.current = setTimeout(() => {
      onSearch();
    }, debounceMs);

    return () => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    };
  }, [term, autoSearch, debounceMs, onSearch, onClear]);

  return (
    <S.Wrapper onSubmit={handleSubmit}>
      <Input
        name="search"
        placeholder="Buscar por título ou conteúdo..."
        icon={faSearch}
        value={term}
        onChange={(e) => setTerm(e.target.value)}
      />
      <Button>Buscar</Button>

      {!!term && (
        <Button type="button" variant="ghost" onClick={handleClear}>
          Limpar
        </Button>
      )}
    </S.Wrapper>
  );
};

export default SearchForm;

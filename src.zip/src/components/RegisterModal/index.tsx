import React from 'react';
import Modal from '../Modal';
import RegisterForm from '../RegisterForm';
import Button from '../Button';

const RegisterModal = () => {
  return (
    <Modal trigger={<Button variant="secondary">Registrar</Button>} title="Criar conta">
      <RegisterForm />
    </Modal>
  );
};

export default RegisterModal;

import React from 'react';
import Modal from '../Modal';
import LoginForm from '../LoginForm';
import Button from '../Button';

const LoginModal = () => {
  return (
    <Modal trigger={<Button>Login</Button>} title="Login">
      <LoginForm />
    </Modal>
  );
};

export default LoginModal;
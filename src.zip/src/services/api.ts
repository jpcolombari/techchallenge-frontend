import axios from 'axios';

// --- Tipagem dos Dados da API ---
export type Post = {
  _id: string;
  title: string;
  content: string;
  author: string;
  createdAt: string;
  updatedAt: string;
};

export type LoginResponse = {
  access_token: string;
};

export type CreateUserPayload = {
  name: string;
  email: string;
  password: string;
};

export type UpdatePostPayload = {
  title?: string;
  content?: string;
  author?: string;
};

// --- Configuração do Axios ---
const api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL,
});

// --- Funções de API ---

/**
 * Busca todos os posts do back-end.
 */
export const getPosts = async (): Promise<Post[]> => {
  const response = await api.get('/posts');
  return response.data;
};

/**
 * Busca um post específico pelo seu ID.
 */
export const getPostById = async (id: string): Promise<Post> => {
  const response = await api.get(`/posts/${id}`);
  return response.data;
};

/**
 * Busca posts por um termo de pesquisa.
 */
export const searchPosts = async (term: string): Promise<Post[]> => {
  const response = await api.get(`/posts/search?term=${term}`);
  return response.data;
};

/**
 * Autentica um usuário.
 * @param credentials Objeto com email e password.
 * @returns Uma promessa que resolve para um objeto com o access_token.
 */
export const loginUser = async (credentials: {
  email: string;
  password: string;
}): Promise<LoginResponse> => {
  const response = await api.post('/auth/login', credentials);
  return response.data;
};

export const registerUser = async (data: CreateUserPayload) => {
  const response = await api.post('/users', data);
  return response.data;
};

export const updatePost = async (id: string, data: UpdatePostPayload) => {
  const res = await api.put(`/posts/${id}`, data);
  return res.data;
};

export const deletePost = async (id: string) => {
  const res = await api.delete(`/posts/${id}`);
  return res.data;
};

export default api;
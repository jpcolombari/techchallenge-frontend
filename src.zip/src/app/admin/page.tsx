'use client';
import { useEffect, useMemo, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { getPosts, type Post } from '@/services/api';
import Container from '@/components/Container';
import Header from '@/components/Header';
import Heading from '@/components/Heading';
import Button from '@/components/Button';
import Spinner from '@/components/Spinner';
import Text from '@/components/Text';
import LoginModal from '@/components/LoginModal';
import SearchForm from '@/components/SearchForm';
import EditPostModal from '@/components/EditPostModal';
import * as S from './page.styles';

export default function AdminPage() {
  const { isAuthenticated, isLoading } = useAuth();

  const [allPosts, setAllPosts] = useState<Post[]>([]);
  const [isLoadingPosts, setIsLoadingPosts] = useState(true);

  const [searchTerm, setSearchTerm] = useState('');

  // Carrega todos os posts ao entrar autenticado
  useEffect(() => {
    if (!isLoading && isAuthenticated) {
      const fetchPosts = async () => {
        setIsLoadingPosts(true);
        try {
          const postData = await getPosts();
          setAllPosts(postData);
        } catch (error) {
          console.error('Falha ao buscar posts:', error);
        } finally {
          setIsLoadingPosts(false);
        }
      };
      fetchPosts();
    } else if (!isLoading && !isAuthenticated) {
      setIsLoadingPosts(false);
    }
  }, [isAuthenticated, isLoading]);

  // Filtro local (título, conteúdo e autor)
  const filteredPosts = useMemo(() => {
    const q = searchTerm.trim().toLowerCase();
    if (!q) return allPosts;
    return allPosts.filter((p) => {
      const t = p.title?.toLowerCase() ?? '';
      const c = p.content?.toLowerCase() ?? '';
      const a = p.author?.toLowerCase() ?? '';
      return t.includes(q) || c.includes(q) || a.includes(q);
    });
  }, [allPosts, searchTerm]);

  const handleSearch = () => {
    // No filtro local, não precisamos fazer nada aqui.
  };

  const handleClear = () => setSearchTerm('');

  if (isLoading) {
    return (
      <main>
        <Header />
        <Container>
          <S.SpinnerWrapper>
            <Spinner />
          </S.SpinnerWrapper>
        </Container>
      </main>
    );
  }

  if (!isAuthenticated) {
    return (
      <main>
        <Header />
        <Container>
          <S.AuthRequiredWrapper>
            <Heading>Acesso Restrito</Heading>
            <Text>Você precisa estar logado para acessar esta página.</Text>
            <S.LoginButtonWrapper>
              <LoginModal />
            </S.LoginButtonWrapper>
          </S.AuthRequiredWrapper>
        </Container>
      </main>
    );
  }

  return (
    <main>
      <Header />
      <Container>
        <S.Intro>
          <Heading>Bem-vindo ao Painel</Heading>
          <Text size="medium">Gerencie, edite e exclua as postagens do blog.</Text>
        </S.Intro>

        <S.SearchRow>
          <SearchForm
            term={searchTerm}
            setTerm={setSearchTerm}
            onSearch={handleSearch}
            onClear={handleClear}
            autoSearch
            debounceMs={300}
          />
          <Text size="small">Mostrando {filteredPosts.length} post(s)</Text>
        </S.SearchRow>

        {isLoadingPosts ? (
          <S.SpinnerWrapper>
            <Spinner />
          </S.SpinnerWrapper>
        ) : (
          <>
            <S.Table>
              <thead>
                <tr>
                  <th>Post</th>
                  <th>Autor</th>
                  <th>Ações</th>
                </tr>
              </thead>
              <tbody>
                {filteredPosts.map((post) => (
                  <tr key={post._id}>
                    <td>
                      <S.PostTitle>{post.title}</S.PostTitle>
                      <Text size="small">{post.content.substring(0, 80)}...</Text>
                    </td>
                    <td>{post.author}</td>
                    <td>
                      <S.Actions>
                        <Button variant="ghost">Editar</Button>
                        <Button variant="ghost">Excluir</Button>
                      </S.Actions>
                    </td>
                  </tr>
                ))}
              </tbody>
            </S.Table>
          </>
        )}
        
      </Container>
    </main>
  );
}

import type { Meta, StoryObj } from '@storybook/react';
import Modal from '.';
import Button from '../Button';

const meta: Meta<typeof Modal> = {
  title: 'Components/Modal',
  component: Modal,
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof Modal>;

export const Default: Story = {
  args: {
    trigger: <Button>Abrir Modal</Button>,
    title: 'Título do Modal',
    children: (
      <div>
        <p>Aqui vai o conteúdo do modal.</p>
        <p>Pode ser um formulário, texto, ou qualquer outro componente.</p>
      </div>
    ),
  },
};
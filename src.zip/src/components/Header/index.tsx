'use client';
import React from 'react';
import * as S from './styles';
import Container from '../Container';
import { useAuth } from '@/contexts/AuthContext';
import LoginModal from '../LoginModal';
import RegisterModal from '../RegisterModal';
import Button from '../Button';
import Link from 'next/link'; 

const Header = () => {
  const { isAuthenticated, logout } = useAuth();

  return (
    <S.Wrapper>
      <Container>
        <S.Content>
          <Link href="/" passHref>
            <S.Title>Tech Challenge Blog</S.Title>
          </Link>

          <S.Nav>
            {isAuthenticated ? (
              <S.UserInfo>
                <Link href="/admin" passHref>
                  <S.AdminLink>Painel</S.AdminLink>
                </Link>
                <span>Bem-vindo, Professor!</span>
                <Button variant="ghost" onClick={logout}>
                  Sair
                </Button>
              </S.UserInfo>
            ) : (
              <>
                <LoginModal />
                <RegisterModal />
              </>
            )}
          </S.Nav>
        </S.Content>
      </Container>
    </S.Wrapper>
  );
};

export default Header;
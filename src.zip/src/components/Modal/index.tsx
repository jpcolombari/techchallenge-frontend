import React from 'react';
import * as Dialog from '@radix-ui/react-dialog';
import * as S from './styles';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTimes } from '@fortawesome/free-solid-svg-icons';

export type ModalProps = {
  trigger: React.ReactNode;
  title: string;
  children: React.ReactNode;
};

const Modal = ({ trigger, title, children }: ModalProps) => {
  return (
    <Dialog.Root>
      <Dialog.Trigger asChild>{trigger}</Dialog.Trigger>
      <Dialog.Portal>
        <Dialog.Overlay asChild>
          <S.Overlay />
        </Dialog.Overlay>
        <Dialog.Content asChild>
          <S.Content>
            <S.Title>{title}</S.Title>
            <Dialog.Close asChild>
              <S.CloseButton aria-label="Close">
                <FontAwesomeIcon icon={faTimes} />
              </S.CloseButton>
            </Dialog.Close>
            {children}
          </S.Content>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
};

export default Modal;